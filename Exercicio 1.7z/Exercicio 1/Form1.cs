namespace Atividade
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        { //entrada
            float idade = float.Parse(txtSla.Text);
        //conta
            idade = idade * 12f;
            //saida
        MessageBox.Show("Sua idade � ="+idade);
        }

        private void txtSla_TextChanged(object sender, EventArgs e)
        {

        }
    }
}