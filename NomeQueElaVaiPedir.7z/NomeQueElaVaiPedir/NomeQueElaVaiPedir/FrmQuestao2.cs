﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NomeQueElaVaiPedir
{
    public partial class FrmQuestao2 : Form
    {
        public FrmQuestao2()
        {
            InitializeComponent();
        }

        private void FrmQuestao2_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Programa de Calculo de IMC");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // +     -     /    *
            float valorPeso = float.Parse(txtPeso.Text);
            float valorAltura = float.Parse(txtAltura.Text);
            float imc;

            imc = valorPeso / (valorAltura * valorAltura);

            lblResultado.Text = "Resultado e :"+imc;
        }
    }
}
