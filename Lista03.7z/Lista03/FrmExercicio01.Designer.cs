﻿namespace Lista03
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl1 = new System.Windows.Forms.Label();
            this.lbl2 = new System.Windows.Forms.Label();
            this.lbl3 = new System.Windows.Forms.Label();
            this.txt1 = new System.Windows.Forms.TextBox();
            this.txt3 = new System.Windows.Forms.TextBox();
            this.txt2 = new System.Windows.Forms.TextBox();
            this.bntSoma = new System.Windows.Forms.Button();
            this.bntPorcentagem = new System.Windows.Forms.Button();
            this.bntMédia = new System.Windows.Forms.Button();
            this.lblrSoma = new System.Windows.Forms.Label();
            this.lblrMédia = new System.Windows.Forms.Label();
            this.lblrPorcentagem = new System.Windows.Forms.Label();
            this.bntLimpar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1.Location = new System.Drawing.Point(100, 108);
            this.lbl1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(96, 24);
            this.lbl1.TabIndex = 0;
            this.lbl1.Text = "Número1";
            this.lbl1.Click += new System.EventHandler(this.lbl1_Click);
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl2.Location = new System.Drawing.Point(310, 108);
            this.lbl2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(96, 24);
            this.lbl2.TabIndex = 1;
            this.lbl2.Text = "Número2";
            // 
            // lbl3
            // 
            this.lbl3.AutoSize = true;
            this.lbl3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl3.Location = new System.Drawing.Point(516, 108);
            this.lbl3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(96, 24);
            this.lbl3.TabIndex = 2;
            this.lbl3.Text = "Número3";
            this.lbl3.Click += new System.EventHandler(this.lbl3_Click);
            // 
            // txt1
            // 
            this.txt1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt1.Location = new System.Drawing.Point(104, 159);
            this.txt1.Margin = new System.Windows.Forms.Padding(4);
            this.txt1.Name = "txt1";
            this.txt1.Size = new System.Drawing.Size(148, 24);
            this.txt1.TabIndex = 3;
            this.txt1.TextChanged += new System.EventHandler(this.txt1_TextChanged);
            // 
            // txt3
            // 
            this.txt3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt3.Location = new System.Drawing.Point(520, 159);
            this.txt3.Margin = new System.Windows.Forms.Padding(4);
            this.txt3.Name = "txt3";
            this.txt3.Size = new System.Drawing.Size(148, 24);
            this.txt3.TabIndex = 4;
            // 
            // txt2
            // 
            this.txt2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt2.Location = new System.Drawing.Point(314, 159);
            this.txt2.Margin = new System.Windows.Forms.Padding(4);
            this.txt2.Name = "txt2";
            this.txt2.Size = new System.Drawing.Size(148, 24);
            this.txt2.TabIndex = 5;
            // 
            // bntSoma
            // 
            this.bntSoma.Location = new System.Drawing.Point(104, 264);
            this.bntSoma.Name = "bntSoma";
            this.bntSoma.Size = new System.Drawing.Size(118, 34);
            this.bntSoma.TabIndex = 6;
            this.bntSoma.Text = "Soma";
            this.bntSoma.UseVisualStyleBackColor = true;
            this.bntSoma.Click += new System.EventHandler(this.button1_Click);
            // 
            // bntPorcentagem
            // 
            this.bntPorcentagem.Location = new System.Drawing.Point(520, 264);
            this.bntPorcentagem.Name = "bntPorcentagem";
            this.bntPorcentagem.Size = new System.Drawing.Size(118, 34);
            this.bntPorcentagem.TabIndex = 9;
            this.bntPorcentagem.Text = "Porcentagem";
            this.bntPorcentagem.UseVisualStyleBackColor = true;
            this.bntPorcentagem.Click += new System.EventHandler(this.bntPorcentagem_Click);
            // 
            // bntMédia
            // 
            this.bntMédia.Location = new System.Drawing.Point(314, 264);
            this.bntMédia.Name = "bntMédia";
            this.bntMédia.Size = new System.Drawing.Size(118, 34);
            this.bntMédia.TabIndex = 10;
            this.bntMédia.Text = "Média";
            this.bntMédia.UseVisualStyleBackColor = true;
            this.bntMédia.Click += new System.EventHandler(this.bntMédia_Click);
            // 
            // lblrSoma
            // 
            this.lblrSoma.AutoSize = true;
            this.lblrSoma.Location = new System.Drawing.Point(311, 344);
            this.lblrSoma.Name = "lblrSoma";
            this.lblrSoma.Size = new System.Drawing.Size(115, 18);
            this.lblrSoma.TabIndex = 11;
            this.lblrSoma.Text = "ResultadoSoma";
            this.lblrSoma.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblrMédia
            // 
            this.lblrMédia.AutoSize = true;
            this.lblrMédia.Location = new System.Drawing.Point(311, 377);
            this.lblrMédia.Name = "lblrMédia";
            this.lblrMédia.Size = new System.Drawing.Size(115, 18);
            this.lblrMédia.TabIndex = 12;
            this.lblrMédia.Text = "ResultadoMédia";
            this.lblrMédia.Click += new System.EventHandler(this.lblrMédia_Click);
            // 
            // lblrPorcentagem
            // 
            this.lblrPorcentagem.AutoSize = true;
            this.lblrPorcentagem.Location = new System.Drawing.Point(311, 410);
            this.lblrPorcentagem.Name = "lblrPorcentagem";
            this.lblrPorcentagem.Size = new System.Drawing.Size(164, 18);
            this.lblrPorcentagem.TabIndex = 13;
            this.lblrPorcentagem.Text = "ResultadoPorcentagem";
            // 
            // bntLimpar
            // 
            this.bntLimpar.Location = new System.Drawing.Point(520, 328);
            this.bntLimpar.Name = "bntLimpar";
            this.bntLimpar.Size = new System.Drawing.Size(118, 34);
            this.bntLimpar.TabIndex = 14;
            this.bntLimpar.Text = "Limpar";
            this.bntLimpar.UseVisualStyleBackColor = true;
            this.bntLimpar.Click += new System.EventHandler(this.bntLimpar_Click);
            // 
            // frmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1200, 623);
            this.Controls.Add(this.bntLimpar);
            this.Controls.Add(this.lblrPorcentagem);
            this.Controls.Add(this.lblrMédia);
            this.Controls.Add(this.lblrSoma);
            this.Controls.Add(this.bntMédia);
            this.Controls.Add(this.bntPorcentagem);
            this.Controls.Add(this.bntSoma);
            this.Controls.Add(this.txt2);
            this.Controls.Add(this.txt3);
            this.Controls.Add(this.txt1);
            this.Controls.Add(this.lbl3);
            this.Controls.Add(this.lbl2);
            this.Controls.Add(this.lbl1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmExercicio1";
            this.Text = " ";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.Label lbl3;
        private System.Windows.Forms.TextBox txt1;
        private System.Windows.Forms.TextBox txt3;
        private System.Windows.Forms.TextBox txt2;
        private System.Windows.Forms.Button bntSoma;
        private System.Windows.Forms.Button bntPorcentagem;
        private System.Windows.Forms.Button bntMédia;
        private System.Windows.Forms.Label lblrSoma;
        private System.Windows.Forms.Label lblrMédia;
        private System.Windows.Forms.Label lblrPorcentagem;
        private System.Windows.Forms.Button bntLimpar;
    }
}

