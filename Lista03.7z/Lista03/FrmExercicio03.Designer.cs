﻿namespace Lista03
{
    partial class FrmExercicio03
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblPeso = new System.Windows.Forms.Label();
            this.txt1 = new System.Windows.Forms.TextBox();
            this.btnValor = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.lblMarmita = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(190)))), ((int)(((byte)(227)))), ((int)(((byte)(219)))));
            this.panel1.Controls.Add(this.lblPeso);
            this.panel1.Controls.Add(this.txt1);
            this.panel1.Location = new System.Drawing.Point(-55, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(973, 134);
            this.panel1.TabIndex = 0;
            // 
            // lblPeso
            // 
            this.lblPeso.AutoSize = true;
            this.lblPeso.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPeso.Location = new System.Drawing.Point(111, 56);
            this.lblPeso.Name = "lblPeso";
            this.lblPeso.Size = new System.Drawing.Size(206, 29);
            this.lblPeso.TabIndex = 2;
            this.lblPeso.Text = "Peso Marmita(g)";
            // 
            // txt1
            // 
            this.txt1.Location = new System.Drawing.Point(337, 65);
            this.txt1.Name = "txt1";
            this.txt1.Size = new System.Drawing.Size(165, 20);
            this.txt1.TabIndex = 0;
            // 
            // btnValor
            // 
            this.btnValor.Location = new System.Drawing.Point(166, 3);
            this.btnValor.Name = "btnValor";
            this.btnValor.Size = new System.Drawing.Size(125, 42);
            this.btnValor.TabIndex = 1;
            this.btnValor.Text = "Valor";
            this.btnValor.UseVisualStyleBackColor = true;
            this.btnValor.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(254, 353);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 1;
            // 
            // lblMarmita
            // 
            this.lblMarmita.AutoSize = true;
            this.lblMarmita.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMarmita.Location = new System.Drawing.Point(161, 83);
            this.lblMarmita.Name = "lblMarmita";
            this.lblMarmita.Size = new System.Drawing.Size(164, 25);
            this.lblMarmita.TabIndex = 2;
            this.lblMarmita.Text = "Preco Marmita";
            this.lblMarmita.Click += new System.EventHandler(this.lblMarmita_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel2.Controls.Add(this.btnValor);
            this.panel2.Controls.Add(this.lblMarmita);
            this.panel2.Location = new System.Drawing.Point(-11, 129);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(954, 230);
            this.panel2.TabIndex = 3;
            // 
            // FrmExercicio03
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(908, 320);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.panel1);
            this.Name = "FrmExercicio03";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblPeso;
        private System.Windows.Forms.TextBox txt1;
        private System.Windows.Forms.Button btnValor;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label lblMarmita;
        private System.Windows.Forms.Panel panel2;
    }
}