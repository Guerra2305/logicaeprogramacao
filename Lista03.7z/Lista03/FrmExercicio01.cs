﻿using System;
using System.Windows.Forms;

namespace Lista03
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            float num1 = float.Parse(txt1.Text);
            float num3 = float.Parse(txt3.Text);
            float soma;

            soma = num1 + num3;

            lblrSoma.Text = "Soma é igual a" + soma;
        }

        private void lbl3_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void lbl1_Click(object sender, EventArgs e)
        {


        }

        private void bntMédia_Click(object sender, EventArgs e)
        {
            float num1 = float.Parse(txt1.Text);
            float num2 = float.Parse(txt2.Text);
            float num3 = float.Parse(txt3.Text);
            float média;
            média = (num1 + num2 + num3) / 3;
            lblrMédia.Text = "A média é de" + média;
        }

        private void bntPorcentagem_Click(object sender, EventArgs e)
        {
            float num1 = float.Parse(txt1.Text);
            float num2 = float.Parse(txt2.Text);
            float num3 = float.Parse(txt3.Text);
            float total, pcrt1, pcrt2, pcrt3;

            total = num1 + num2 + num3;
            pcrt1 = num1 / total * 100;
            pcrt2 = num2 / total * 100;
            pcrt3 = num3 / total * 100;

            lblrPorcentagem.Text = "num1 é" + pcrt1 + "% - " + "num2 é" + pcrt2 + "% -" + "num3 é" + pcrt3 + "% -";



        }

        private void bntLimpar_Click(object sender, EventArgs e)
        {

            float num1 = float.Parse(txt1.Text);
            float num2 = float.Parse(txt2.Text);
            float num3 = float.Parse(txt3.Text);
            float div = num1 + num2 + num3;

            div = num1 + num2 + num3/0;


           // bntLimpar = float.Parse
        }

        private void txt1_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblrMédia_Click(object sender, EventArgs e)
        {

        }
    }
}

