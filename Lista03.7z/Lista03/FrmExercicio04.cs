﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lista03
{
    public partial class FrmExercicio04 : Form
    {
        public FrmExercicio04()
        {
            InitializeComponent();
        }

        private void btnArea_Click(object sender, EventArgs e)
        {
            float num1 = float.Parse(txt1.Text);
            float num2 = float.Parse(txt2.Text);
            float mult;
            mult = num1 * num2;
            lblArea.Text = "A area do quadrado é de" + mult;


        }
    }
}
